You need to run the files in a local web server to work !
